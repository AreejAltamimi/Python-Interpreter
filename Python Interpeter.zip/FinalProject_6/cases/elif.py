x=2
if x%2 == 0:
  print 99
  x = 17
  if x: 
    print 11
  elif x == 2:
    print 101
  else:
    print 100 
