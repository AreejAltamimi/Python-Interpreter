x=9
y=-9
def f():
  x = -4
  y = 7
  if x != 0: 
    print 99
    x = 1
    if x >= -y: 
      print 1
      return x*x/2
      if x <= y:
        print 2
        return 
      else: 
        return x
    else: 
      print 2
      return y%x**2//1.5
    print x
  else:
    print ---x+++y

f()
print 17
print x
print y
