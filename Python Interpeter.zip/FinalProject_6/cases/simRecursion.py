def f(x):
  if x == 0:
    return 0
  else:
    print x
    return f(x-1)
    print 99

print f(5)
print 888888
print f(8)
