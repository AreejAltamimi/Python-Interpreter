def f():
  print 3
  def g():
    x=2   
    print x
    return 6
    print 10
  g()
  y = 4
  return y
  print 100

print f()

