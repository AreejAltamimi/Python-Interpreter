x=5
y=-1.5
def f():
  print 3
  x=4
  print x**x//2
  def g():
    x=2   
    print x
    return -100
    print 10//x
    def h():
      x=9
      print x
      return
      def m():
        return y
      m()
    h()
  g()
  y = 4
  return y**2+x//4-x%y
  print 99.99

print f()
f()

