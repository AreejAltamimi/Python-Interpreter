x = 0
while x < 5 :
  print 1
  x += 1
  print x
print x
