def f():
  print 6

f()
f()
f()
