print 2%3
print -2%3
print 2%-3
print -2%-3

print 9.9%5.68
print -9.9%5.68
print 9.9%-5.68
print -9.9%-5.68

print 5.6%6
print -5.6%6
print 5.6%-6
print -5.6%-6

print 7%3.2
print -7%3.2
print 7%-3.2
print -7%-3.2

print (-4.5)%3
print 8%(-1.0)
