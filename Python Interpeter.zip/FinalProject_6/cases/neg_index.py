x='ABCDEFG'
print x[-1]
