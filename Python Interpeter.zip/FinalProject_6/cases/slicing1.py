x='ABCDEFG'
print x[0:-1]
