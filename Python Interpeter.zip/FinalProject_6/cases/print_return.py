def f():
  x=9
  y=5
  return x
  print x
  def g():
    return y  
    print x
  g()

f()

