def fib(n):
    if n == 1:
        return 0
    if n == 2:
        return 1
    else:
        return fib(n-2) + fib(n-1)

result = fib(6)
print result

x = fib(10)
print x
print fib(9)
print fib(12)
print fib(24)
