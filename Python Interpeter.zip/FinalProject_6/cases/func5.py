x=5
y=-1.5
def f():
  print 3
  x=4
  print x**x//2
  def g():
    x=2   
    print x
    return 66.6
    print 10
    def h():
      x=9
      print x
      return
    h()
  g()
  y = 4
  return y+x
  print 100

f()
f()
