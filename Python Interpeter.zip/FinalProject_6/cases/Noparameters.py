x=6
def k():
  print x
  def h():
      x=88
      print x
  h()
k()
