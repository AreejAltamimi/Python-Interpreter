print -1/2
print -1/2-1/2
print -1/2+(-1/2)
print 2.5+.5
print +3
print 7.9+4-(4.4-3)+15

print 5/2
print 5/-2
print -5/2
print -5/-2
print 4.8/3.5
print -4.8/-3.5
print -4.8/3.5
print 4.8/-3.5
print 99/56.45
print -34/-5.45
print 56.45/-99
print -34/5.45

print 3*7
print 3.8*9
print 34*2.4
print 6.8*9.99
print -5*-8
print -34*2.4
print 3.8*-9
print -4.55*-5.6
print 3/8.0*(-3/4)
print (4/7*1.2+3.34)-2*(3/4.0)

print ++++++++++6
print ++++3.5-------1
print ------------1
print 2.5--------1
print -1-------1
print -1--------1
print 6.8*4/3-----5+++++9
