def cascade(n):

        if n < 10:
            print n
        else:
            print n
            cascade(n//10)
            print n

cascade(2017)
print 111111111
cascade(5390)
