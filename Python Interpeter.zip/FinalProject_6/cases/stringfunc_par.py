x='abc'
y=3
def f(x, y):
  z=x*y
  w=x
  v=x+z 
  print z
  print w
  print v
  def g(x,y,z):
    print x+z
    w=x*y
    return w
  g('a',2,'c')

f('abc',3)
f('def',2)
