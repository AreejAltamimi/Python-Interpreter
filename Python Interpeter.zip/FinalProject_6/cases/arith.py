a =11
b=11
c=11
print a
print b
print c
x = 10.0
x += 2
print x
x -= 10
print x
x *= 2
print x
x /= 4
print x
x %= 2
print x
x = 3
x **= 2.0
print x
x //= 10
print x

print 2 + 3 * 5
print -2.0
print 1.0 - 2

print -1/2
print -1/2 - 1/2
print -1/2 + -1/2

print 2**3
print -1**2

print 3.0 // 2
print 3.0 / 2

print -5%2
print 5%-2
