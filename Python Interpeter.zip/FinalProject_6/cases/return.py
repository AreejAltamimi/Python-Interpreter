def f(x):
  if x == 0: 
    print 99
    x = 17
    if x: 
      print 11
      return
  elif x == 2:
    print 101
  else:
    print 100 

x = 2
f(x)
print 17
