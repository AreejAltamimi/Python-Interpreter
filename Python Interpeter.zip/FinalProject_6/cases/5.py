x=10
def f():
    T()
    if x>7:
        y=8
        print x
        print y
    def g():
        x = 1
        x=5
        if x>1:
            x=9
            return
        else:
            print x
        def h():
            x=3
            print x
        h()
    g()

def T():
    x=56
    return x
    print 99
    y=8
    print y

f()
x*=4
print x
print T()
print 4
