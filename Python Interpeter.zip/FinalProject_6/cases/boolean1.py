def f():
  print 1
  if True:
    print 2
  return 
  print 4

f()

