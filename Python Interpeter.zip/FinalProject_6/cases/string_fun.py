def f():
  print "abcdef"
  y="34125678"
  print y[0:4:2]


f()
