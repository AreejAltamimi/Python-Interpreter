x='ABCDEFG'
print x
