x = 1
print "check: x"
print x
if x > 0: 
  print "is"
  if x%2 == 0:
   print "even"
  elif x%2 == 1:
    print "odd"
elif x == 0:
  print "Zero"
else: 
  print "-ve"
