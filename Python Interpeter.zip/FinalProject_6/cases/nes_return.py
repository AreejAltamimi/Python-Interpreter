def f():
  x=9
  y=5
  print x
  return x
  def g():
    print x
    return y
  g()

f()

