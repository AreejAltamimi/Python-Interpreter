x='abc'
print x
